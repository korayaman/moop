<link href="view/Theme/assets/test.css" rel="stylesheet">
<p class='renklendir'>Tema uzerinden veri alma testi yapalim </p>
