<title>Anasyfa Title</title>

<div class="container-fluid p-5 bg-primary text-white text-center">
  <h1>Tebrikler</h1>
  <p>Kutuphane Calistirildi</p> 
</div>

<div class="container mt-5">
  <div class="row">
    <div class="col-sm-12">
      <h3>Tebrikler</h3>
      Moop Kutuphanesine hosgeldin .. Bu kutuphane standart Vue ve Bootsrap Kutuphanelerini CDN olarak icerisinde barindirmak ile beraber kullanimini simdi ogrenicez <br>
      Kutuphanemizin en buyuk ozelligi basic seviyede olmasidir gereksiz hic bir sey bulunmamak ile beraber gerekli olan hic bir sey de yoktur :) <br>
      ne demek bu standart bir web sitesi icin gerekli ekipmanlar ve yapi vardir fakat program ilerledikce ihtiyaclar dogacak ve bu ihtiyaclar icin kendiniz yapmaniz gerekmektedir  
      <br>
      ornek icin fonksiyon yapimi bolumunu inceleyeniz
    </div>
    <hr>
    

    <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#yapi">Yapi Tanitimi</button>
    <div id="yapi" class="collapse">
    Yapi tanitimi :  MVC ve OOP den esinlenen ve Fonksiyonel olarak yapilandirilmis icerisinde CRUD sistem barindiran basic bir kutuphanedir .. <br>
    hazir fonksiyonlar sayesinde ekleme kaldirma silme listeleme gibi ozelliklerin yani sira Self link gorsel ekleme guvenlik gibi belirli standartlarinda icinde bulunan 
    moop kutuphanesinde yaziliminiz icin gerekli olan fonksiyonlarin ayarlanmasi icin controller/site.php uzerinden kendi fonksiyonlarinizi yazmaniz icin size ozel alan birakilmistir 
    <hr>
    </div>
    
    <hr>

    <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#app">APP Nedir nasil kullanilir</button>
    <div id="app" class="collapse">
    viwer yapisinda APP klasorunun icinde klasor olusturup daha sonra icerisine index.php yaratmaniz yeterli olacaktir artik body icerisinde calisir 
    <br> site.com/deneme  seklinde calisacaktir ... APP klasorunun icindeki deneme klasorune girer ve ordaki index.php yi araya alir header ve footer sabit kalir arasi da body olarak calisir 
    <hr>
    </div>
    <hr>
    <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#crud">Crud Yonetimi</button>
    <div id="crud" class="collapse">
    Crud sistemi ile neler yapabiliriz : <br>

    Ilk Ornegimiz Sorgu olsun SQL uzerinden islem yapmamiz lazim uyeleri listeleyelim <br>
    <pre>
    $uyeler=sorgu("select * from uyeler");
    foreach ($uyeler as $rs) {
        echo $rs[id];
    }
    </pre>
    Simdi Bir Uye Ekleme yapalim tablomuz uye olsun ad soyad eposta diye de 3 adet veri olsun  <br>
    <pre>
        $uyeEkle=ekle("uye",array(
            "ad"=>"uye Adi",
            "soyad"=>"soy adi",
            "eposta"=>"deneme@deneme.com"
        ));
    </pre>
    Bu Kadar evet artik uye sql inde yeni bir uyemiz var 
    <br>
    simdi guncelleme den bir ornek yapalim <br>
    <pre>
        $set="
        ad='yeni adi',
        soyad='yeni soyadi',
        eposta='yeni@eposta.com'
        ";
        $uyeGuncelle=guncelle("uye","{$set}","1");
    </pre>
    Burda Fark ettiyseniz bir set degiskeni tanimladik ve neleri guncellemek istedigmizi yazdik ve en son 1 olarak bir id deger gonderdik 
    iste bu kadar artik guncellemeniz de tamamlandi
    <br>
    Simdi birde Kaldirma uzerinden Ornek yapalim
    <pre>
    $kaldir=kaldir("uye","1");
    </pre>
    Evet Kaldirma da tamamlandi uye tablosunun icindeki id 1 olani kaldirdik 
    <hr>
    Tum CRUD sistemlerini Yapilandirdigimizda Gore Artik dilediginiz sekilde programinizi gelistirebilirsiniz Hayirli Olsun 

    </div>

    <hr>
    <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#fonksiyon">Fonksiyon Yapimi</button>
    <div id="fonksiyon" class="collapse">
    <br>
      Ornek : Uygulamaniz da KDV hesaplamaniz gerekiyor bunu nasil yapariz <br>
      controller/site.php uzerinde 
        <pre>
            function KDV($tutar,$oran)
            {
                $sonuc=$tutar*$oran/100;
                return $sonuc;
            }
        </pre>
        Fonksiyonumuzu yaptik ve lazim olan bir alan oldugunda kullanimi 
        <pre>
            $kdvGetir=KDV(100,18);
            echo $kdvGetir;
        </pre>
        Dediginizde size Girilen rakam ve oran da kdv hesaplar bu ornekteki gibi projenize gore fonksiyonlar dan gelistirme isi size ait bu kutuphanenin amaci herseyi hazir vermek degil sadece 
        sistemi toplayalim yazilim siz de olsun mantiginda kurulmustur yukaridaki ornek gibi bir cok fonksiyonlar sorgular gelistirmek size ait :) zaten olmasi gerekende bu <br>
        Mesela bir ornek daha yapalim bu biraz zor olsun :) <br>
        istek = bir urun agaci olsun ve orda urunler ve markalarin oldugu bir tablo olsun bu tabloda marka baska bir tabloda olsun simdi bunlari birlestirip bir ciktiya ihtiyacimiz var 
        peki bunu nasil yapabiliriz .... Soru bu simdi urun diye bir fonksiyon yapalim ve bu bu isi yapsin 
        <pre>
            function urun()
            {
                // tum urunleri getirecek ve bunlari markalarini baska tablodan alacak 
                $urunlerim=sorgu("
                select 
                urun.urunAdi,
                markalar.marka
                from urun
                left join markalar on markalar.id=urun.marka
                ");

                return $urunlerim;
            }
        </pre>
        evet gordugunuz gibi CRUD dan sorguyu kullandim sorguda left join methodu ile markalarimi istedim ve toplayip 
        verdim gibi  buna benzer gelistirmeleri kendi kendinize ogrenebilirsiniz...
    
    <hr>
    </div>

    <hr>
    
            
    <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#tema">Tema Kurulumu</button>
    <div id="tema" class="collapse">
    <br>
    Tema Nasil Kurulur : Projenize internet den indirmis oldugunuz HTML temalari nasil entegre edeceksiniz ....
    <br>
    view klasorunun icerisinde Theme Klasoru mevcut bu klasorun icerisine Indirmis oldugunuz html dosyalarini atin <br>
    daha sonra index.html dosyasini acip bir inceleyin .. icerisinde style dosyalarini goreceksiniz .... 
    bu CSS javascript gibi dosyalari calistirmak icin eger sabit ise css ler baska sayfada degismiyor hep sabit css ise 
    <br> view/app/header.php icerisine entegre edebilirsiniz <br>
    eger surekli farkli css ve javascriptler donuyor ise app/anasayfa/index.php gibi olusturdugunuz app lerin icine atabilirsiniz <br>
    Gelelim yapisina <br>
    size Dosya su sekilde gelecektir 
    <pre>
    link href="assets/test.css" rel="stylesheet" 
    </pre>
    Siz bu klasor yapsinin basina 
    <pre>
    link href="view/Theme/assets/test.css" rel="stylesheet
    </pre>
    seklinde guncellemeniz gerekmekte bu kadar temaniz sisteme entegre oldu 
    wiew/Theme/ seklinde yolu yenilemeniz yeterli olacaktir 
    
    <hr>
    </div>
    <hr>


    
    <div class="alert alert-success">
        <strong>Teknik Destek !</strong> 
        Kafaniza takilan bir sey olursa Koray YAMAN : 0532 307 95 63 Nolu Telefondan Bana Ulasabilirsiniz...
    </div>

        </div>
</div>
<?php

?>


