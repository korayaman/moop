<?php
// site controller kismi burasi
function markalar()
{
    $markaGetir=sorgu("select * from markalar");
    return $markaGetir;
}
?>