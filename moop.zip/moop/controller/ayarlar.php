<?php
// Standart Site Ayarlar
$firma="KoRaYaMaN"; // Hangi Firma ise footer vb yerlerde firma ismi kullanmak icin 
$telefon="0532 307 95 63"; 
$adres="Deneme Adresi"; 


// Database Ayarlar
$mysqlsunucu = "localhost";
$mysqlkullanici = "u0300508_gonen"; // kullanici adiniz
$mysqlsifre = "mksi.C4J:27HS1:@"; // kullanici sifreniz
$veriTabani="u0300508_gonen";    // db ismi


// Image Ayarlar
$klasor="images";// image klasorunun yolunu belirlemek icin kullanilir


// Eposta Ayarlar


// Gerekli componentler
include "model/database.php";
include "model/fonksiyon.php";
include "model/crud.php";
?>