
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Merhaba</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container-fluid p-5 bg-primary text-white text-center">
  <h1>Moop Kutuphanesi</h1>
  <p>Kurulum ve Hatalar Listesi</p> 
</div>
  
<div class="container mt-5">
            <div class="alert alert-danger">
            <?php
            echo "Problem : " . $e->getMessage();
            ?>
        </div>
    <div class="row">
        <div class="col-lg-12">Kurulum <br>
        
        <ul class="list-group">
            <li class="list-group-item">1. Asama SQL PDO Eklenti Kontrol Eger CPanel de PDO Kapali ise size uyari verecektir Cpanel den PDO yapilandirmanizi gerceklestiriniz </li>
            <li class="list-group-item">2. SQLSTATE[28000] [1045] Access denied for user Hatasi CPanel uzerinden bir SQL olusturun ve Gerekli baglantilari controller/Ayarlar.php Bolumunde yapilandirin</li>
            <li class="list-group-item">3. Eger Yenile dediginizde bu sayfa kaybolduysa Tamamdir gule gule kullanin </li>
        </ul>


        </div>
    </div>
    
</div>

</body>
</html>
