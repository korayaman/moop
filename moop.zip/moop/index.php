<?php
// Controller Yapisini Entegre Edelim 
include "controller/ayarlar.php";
// controller yapisi sonu 

include "view/APP/header.php"; // standart header
// index Yapisinda Dinlemeye Gecelim  ve yapiya gore body eklentisini olusturualim 
if (empty($_GET["sayfa"]))
{
    // Sayfa Dinlemesinde herhangi bir sayfa Degiskenimiz yok ise 
    include "view/APP/anasayfa/index.php";
}
else
{
    $sayfa=koruma($_GET["sayfa"]);
    $file = "view/APP/{$sayfa}/index.php";
    if(is_file($file)) 
    {
        include "{$file}";
    } 
    else 
    {
        include 'view/APP/404/index.php';
    }
}
include "view/APP/footer.php"; // standart footer 
?>
