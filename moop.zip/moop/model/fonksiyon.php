<?php
// Sistemsel Fonksiyonlar buraya gelecek 
session_start();
ob_start();

function koruma($xyz)
  {
    // guvenlik Prosedürü TAMAM eski içerisinde gecen
    $tehlikeli   = array("and","union","delete","like","'","where","AND","UNİON","DELETE","LIKE");// gelıstır burayı
    $kaldir   = "";
    $cevir = str_replace($tehlikeli, $kaldir, $xyz);
    $temiz=filter_var($cevir, FILTER_SANITIZE_STRING); 
    return $temiz;
  }

function linkci($text)
{
  $find = array('Ç', 'Ş', 'Ğ', 'Ü', 'İ', 'Ö', 'ç', 'ş', 'ğ', 'ü', 'ö', 'ı', '+', '#');
    $replace = array('c', 's', 'g', 'u', 'i', 'o', 'c', 's', 'g', 'u', 'o', 'i', 'plus', 'sharp');
    $text = strtolower(str_replace($find, $replace, $text));
    $text = preg_replace("@[^A-Za-z0-9\-_\.\+]@i", ' ', $text);
    $text = trim(preg_replace('/\s+/', ' ', $text));
    $text = str_replace(' ', '-', $text);
    return $text;
}

function yonlendir($sayfa)
  {
    // sayfa yonlendirmesi yapar 
    $yonlendir=''.$sayfa.'';
    echo "<script>window.location.href='".$yonlendir."';</script>";
    return $sayfa;
  }

function cikis($sayfa=null)
{
  // session kapatir 
  if ($sayfa=="")
    {
      session_start();
      session_destroy();
      yonlendir("anasayfa");
    }
    else
    {
      session_start();
      session_destroy();
      yonlendir("{$sayfa}");
    }
}

function eposta($mail,$konu,$metin,$olumlu=null)
{      
  ///

    $istek = new Crud();
    $talep=$istek->listele("admin");
    foreach ($talep as $rs) {
      $host=$rs["mail_host"];
      $gonderici=$rs["sistem_mail"];
      $gonderici_sifre=$rs["mail_sifre"];
      }
        $alici=$mail;
        $konu=$konu;
        $metin=$metin;

        $mail = new PHPMailer(true);
      $mail->isSMTP();
      $mail->Host = ''.$host.'';
      $mail->Port = 587;
      
      $mail->SMTPAuth = true;
      $mail->SMTPAutoTLS = true; // smtp hatasına gore true false yaparsın

      $mail->Username = ''.$gonderici.'';
      $mail->Password = ''.$gonderici_sifre.'';

      // mail gonderme algorıtması 
      $mail->CharSet = 'utf-8'; 
      $mail->setFrom(''.$gonderici.'', ''.$firma_ismi.''); // Kime Gidecek Kısmı Sanısam
      $mail->addReplyTo(''.$gonderici.'', ''.$firma_ismi.''); // yanıt adresı buraya yazar
      $mail->addAddress(''.$alici.'', ''.$firma_ismi.''); // gideccek kısmı
      $mail->Subject = ''.$konu.'';
      //$mail->msgHTML(file_get_contents('contents.html'), __DIR__);
      $mail->Body="{$metin}";
      $mail->AltBody = 'alt body buraya';
      //$mail->addAttachment('images/phpmailer_mini.png');


      if (!$mail->send()) {
          echo 'Mailer Error: ' . $mail->ErrorInfo;
      } else {
          yonlendir("{$olumlu}");
      }
}

function gorselEkle($gorsel=null,$konum,$boy="800",$yuk="600")
  {
     // gorsel ekleme
     $boy=$boy;
     $yuk=$yuk;
     $yol = "images/";

     if (strlen($_FILES[''.$konum.'']['name']))
     {
       if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
       {
         $gecerli_formatlar = array("jpg","jpeg","png","gif","webp");
         $yeni_adi= array("");
         $dosyaadi=linkci($_FILES[''.$konum.'']['name']); // seo dan gecırelım turkce karakter sornu da cozulsun
         $boyutu = $_FILES[''.$konum.'']['size']; // dosyanın boyut bılgısını alıp kontrole sokuyoruz 
           
           if(strlen($dosyaadi))
           {
             // explode ıle . dan ayırıp uzantı ve dosya ısmını aldık asd-ad.png gıbı 
             list($txt, $uzanti) = explode(".", $dosyaadi);
             $uzanti= strtolower($uzanti);
               if(in_array($uzanti,$gecerli_formatlar)) // gecerlı formatlar arrayından bakalım ıstedıgımız mı farklımı
               {
                 //if($boyutu<(2048*2048)) // boyutu kontrul
                 //{
                   $yeni_adi="{$txt}.{$uzanti}"; // txt olarak seo fonksıyonununda - lerı aldık uzantı ıle de png jpg aldık bırlestırdık
                   $gecici = $_FILES[''.$konum.'']['tmp_name'];
                   $sql_icin=$yeni_adi;// sql ıcın de dırek bırlesmısını aldık 
                   
                   if(move_uploaded_file($gecici, $yol.$yeni_adi))
                     { 
                       $dosya=$yol.$yeni_adi;
                       // gecerlı formatlarımız 
                       if ($uzanti=="jpg"  || $uzanti=="jpeg" )
                       $resim = imagecreatefromjpeg($dosya);  
                       if ($uzanti=="png")
                       $resim = imagecreatefrompng($dosya);
                       if ($uzanti=="gif" )
                       $resim = imagecreatefromgif($dosya);
                       // boyutlandırma
                       $boyutlar = getimagesize($dosya);
                       $resimorani = $boy / $boyutlar[0];
                       $yeniyukseklik =$resimorani*$boyutlar[1];
                       $yeniresim = imagecreatetruecolor($boy, $yeniyukseklik); // en boy oranlanmıs halı
                       if ($uzanti=="png" || $uzanti=="gif")
                         {
                         imagecolortransparent($yeniresim, imagecolorallocatealpha($yeniresim, 0, 0, 0, 127));
                         imagealphablending($yeniresim, false);
                         imagesavealpha($yeniresim, true);
                         } 
                     imagecopyresampled($yeniresim, $resim, 0, 0, 0, 0, $boy, $yeniyukseklik, $boyutlar[0], $boyutlar[1]);
                     $hedefdosya=$yol.$yeni_adi;
 
                       switch($uzanti) {
                       case "gif":
                       imagegif($yeniresim,$hedefdosya); 
                       break;
                       case "jpeg":
                       case "jpg":
                       imagejpeg($yeniresim,$hedefdosya,100); 
                       break;
                       case "png":
                       case "x-png":
                       imagepng($yeniresim,$hedefdosya);  
                       break;
                       chmod ($hedefdosya, 0755);
                       }
                     } 
                 //}
               }
           }
       }
 
     }
     return $sql_icin;
  }


?>