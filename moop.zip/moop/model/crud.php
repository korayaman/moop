<?php
// CRUD sisteminin Kurulumunu yapalim 

// SQL Sorgusunu alip geri Array olarak dondurur
function sorgu($tablo)  
{
    include 'database.php';
    $calistir = $conn->prepare("{$tablo}");
    $calistir->execute();
    while ($cikti = $calistir->fetch(PDO::FETCH_ASSOC)) {
        $sonuc[]=$cikti;
    }
    return $sonuc;
}

// DB veri Eklemek icin kullanilir 
/*
    ekle("tablo ADI", array (array olarak veri gonderirlir stun ismi ve bilgi) );
    bu kadar ekleme bitti 
*/
function ekle ($tablo,$data=array(),$geri=null)
{
    include 'database.php';
    foreach ($data as $key => $value) {
        // code...
        $sutun[]=$key;
        $deger[]="'".$value."'"; // sql kayıt ıcın 'deger' seklınde olması ıcın bu sekılde yapıyoruz
    }
        $sutun=implode(",", $sutun); // , ile bır bırlerınden ayırma methodunu kullanıyoruz
        $deger=implode(",", $deger); // , ile bır bırlerınden ayırma methodunu kullanıyoruz

        // veriler istediğimiz gibi array olarak alındıkdan sonra insert into methodumuzu yazıyoruz
        $islem=$conn->prepare("INSERT INTO {$tablo} ({$sutun}) VALUES ({$deger}) ");
        if($islem->execute()) {
                while($rows = $islem->fetch()) {
                    $fetch[] = $rows;
                }
                // geri eklentisi işlemden sonra gerı donmek ıstedıgımız sayfayı belırlememıze yarar ekle ıslemınden sonra hangı sayfaya gıdeceksın ?
                if(empty($geri))
                {
                    return $fetch;
                }
                else
                {
                yonlendir("{$geri}");
                }
            }
            else 
            {
                return false;
            }
}

// Veri Guncellenmesi
function guncelle ($tablo,$set,$id,$geri=null)
{
    include 'database.php';
    $islem = $conn->prepare('UPDATE '.$tablo.' SET '.$set.' WHERE id='.$id.'');
    if($islem->execute()) {
          while($rows = $islem->fetch()) {
              $fetch[] = $rows;
          }
           // geri eklentisi işlemden sonra gerı donmek ıstedıgımız sayfayı belırlememıze yarar ekle ıslemınden sonra hangı sayfaya gıdeceksın ?
           if(empty($geri))
           {
               return $fetch;
           }
           else
           {
              yonlendir("{$geri}");
           }
      }
      else 
      {
          return false;
      } 
}

// kaldir 
function kaldir($tablo,$data,$geri=null)
{
    include 'database.php';
    $islem = $conn->prepare("DELETE FROM {$tablo} WHERE id={$data}");
    if($islem->execute()) {
          while($rows = $islem->fetch()) {
              $fetch[] = $rows;
          }
           // geri eklentisi işlemden sonra gerı donmek ıstedıgımız sayfayı belırlememıze yarar ekle ıslemınden sonra hangı sayfaya gıdeceksın ?
           if(empty($geri))
           {
               return $fetch;
           }
           else
           {
              yonlendir("{$geri}");
           }
      }
      else 
      {
          return false;
      } 
}


// diger fonksiyonlar calissin diye onlari da ekleyeleim 
include 'controller/site.php';
?>