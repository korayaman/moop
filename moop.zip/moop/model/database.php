<?php
if (extension_loaded("PDO")) 
{
    try {
        $conn = new PDO("mysql:host=$mysqlsunucu;dbname=$veriTabani;charset=utf8", $mysqlkullanici, $mysqlsifre);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo "Bağlantı başarılı"; // eger basarili yazisini gorurseniz tamamdir bunu silebilirsiniz 
        }
        catch(PDOException $e)
        {
            include 'controller/install.php';
        }
}
else
{
    include 'controller/pdoHata.php';
}


?>