-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 07 Eki 2022, 19:48:56
-- Sunucu sürümü: 10.3.36-MariaDB-cll-lve
-- PHP Sürümü: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `u0300508_gonen`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `eposta` text NOT NULL,
  `kul` text NOT NULL,
  `sif` text NOT NULL,
  `mail_host` text NOT NULL,
  `sistem_mail` text NOT NULL,
  `mail_sifre` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `eposta`, `kul`, `sif`, `mail_host`, `sistem_mail`, `mail_sifre`) VALUES
(1, 'mail@mail.com', 'onder', 'onder', 'mail.siteadi.com', 'info@siteadi.com', 'mail_sifresi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `icerikler`
--

CREATE TABLE `icerikler` (
  `id` int(11) UNSIGNED NOT NULL,
  `anasayfaBaslik` text DEFAULT NULL,
  `anasayfaYazi` longtext DEFAULT NULL,
  `sloganBaslik` text DEFAULT NULL,
  `sloganYazi` text DEFAULT NULL,
  `hakkimizda` text DEFAULT NULL,
  `hakkimizdaYazi` longtext DEFAULT NULL,
  `iletisimBaslik` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `icerikler`
--

INSERT INTO `icerikler` (`id`, `anasayfaBaslik`, `anasayfaYazi`, `sloganBaslik`, `sloganYazi`, `hakkimizda`, `hakkimizdaYazi`, `iletisimBaslik`) VALUES
(1, 'Anasayfa Baslik Buraya', 'Anasayfa Yazisi Buraya Gelecek SQL Tabanli alan', 'Slogan Baslik', 'Slogan Yazi', 'Biz Kimiz', '1999 dan bugune bla bla bla bla ', 'Size Nasil Yardimci Olabilriz ?');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `id` int(11) UNSIGNED NOT NULL,
  `ad` text DEFAULT NULL,
  `posta` text DEFAULT NULL,
  `tel` text DEFAULT NULL,
  `mesaj` text DEFAULT NULL,
  `durum` int(11) DEFAULT 1,
  `cevap` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategoriler`
--

CREATE TABLE `kategoriler` (
  `id` int(11) UNSIGNED NOT NULL,
  `alt_kat` int(11) DEFAULT NULL,
  `kategori` text DEFAULT NULL,
  `sira` int(11) DEFAULT NULL,
  `gorsel` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `kategoriler`
--

INSERT INTO `kategoriler` (`id`, `alt_kat`, `kategori`, `sira`, `gorsel`) VALUES
(1, 0, 'Rulman', 1, NULL),
(2, 0, 'Güç aktarım sistemleri', 2, NULL),
(3, 0, 'Sanayi tekerlekleri', 3, NULL),
(4, 0, 'V kayış ve yağ lehçeleri', 4, NULL),
(5, 0, 'Hırdavat', 5, NULL),
(6, 0, 'CİVATA ve bağlantı elemanlar', 6, NULL),
(7, 0, 'Tesisat malzemeleri', 7, NULL),
(8, 0, 'Boya grubu', 8, NULL),
(9, 0, 'Kimyasal ürünler', 9, ''),
(10, 0, 'İş güvenlik malzeme', 10, ''),
(11, 0, 'Hortum grubu', 11, ''),
(12, 1, 'Eğik Bilyalı Rulmanlar', 1, ''),
(27, 1, 'Oynak Bilyalı Rulmanlar', 2, ''),
(26, 1, 'Eksenel Bilyalı Rulmanlar', 3, ''),
(25, 1, 'Silindirik Makaralı Rulmanlar', 4, ''),
(24, 1, 'Konik Makaralı Rulmanlar', 5, ''),
(30, 8, 'Defne Boya', 6, ''),
(45, 44, 'duzen 2', 1, NULL),
(42, 41, 'deneme alt kategorisi', 1, NULL),
(32, 8, 'Defne Boya Sökücü', 6, ''),
(44, 0, 'Deneme Kat', 1, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `markalar`
--

CREATE TABLE `markalar` (
  `id` int(11) UNSIGNED NOT NULL,
  `marka` text DEFAULT NULL,
  `gorsel` text DEFAULT NULL,
  `sira` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `markalar`
--

INSERT INTO `markalar` (`id`, `marka`, `gorsel`, `sira`) VALUES
(1, 'Black&Deckers', 'black.png', 1),
(2, 'SKF', 'skf.jpeg', 3),
(3, 'BALATLI', 'balatli.png', 4),
(4, 'BOSCH', 'bosch.png', 5),
(5, 'CETA', 'ceta.png', 6),
(6, 'Makita', 'makita.webp', 1),
(7, 'DF', 'defne.jpeg', 8),
(8, 'yeni test markasi', NULL, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urun`
--

CREATE TABLE `urun` (
  `id` int(11) UNSIGNED NOT NULL,
  `urunAdi` text DEFAULT NULL,
  `marka` int(11) DEFAULT NULL,
  `gorsel` text DEFAULT NULL,
  `kat_id` int(11) DEFAULT NULL,
  `alt_kat` int(11) DEFAULT NULL,
  `aciklama` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `urun`
--

INSERT INTO `urun` (`id`, `urunAdi`, `marka`, `gorsel`, `kat_id`, `alt_kat`, `aciklama`) VALUES
(1, 'Defne Mavi ', 7, 'test.png', 9, 30, '<p>Urun tanitim icerigi buraya gelecek word den kopyala yapistir ozelligi mevcut</p>\r\n'),
(4, 'Defne Boya sokucu guncellemesi', 3, 'test.png', 9, 32, 'Boya Malzemesi guncellemesi\r\n'),
(3, 'bosch matkap', 4, 'test.png', 5, 24, 'bosch matkap');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `icerikler`
--
ALTER TABLE `icerikler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kategoriler`
--
ALTER TABLE `kategoriler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `markalar`
--
ALTER TABLE `markalar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `urun`
--
ALTER TABLE `urun`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `icerikler`
--
ALTER TABLE `icerikler`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `iletisim`
--
ALTER TABLE `iletisim`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `kategoriler`
--
ALTER TABLE `kategoriler`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Tablo için AUTO_INCREMENT değeri `markalar`
--
ALTER TABLE `markalar`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `urun`
--
ALTER TABLE `urun`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
